﻿namespace ECommerce.Web.Models.Login;

public class LoginViewModel
{
    public string email { get; set; }
    public string password { get; set; }


}
